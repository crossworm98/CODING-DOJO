for i in range(1, 151):
    print(i)

for i in range(5, 1000, 5):
    print(i)

for i in range(1, 100):
    if i % 5 == 0:
        print("Coding")
    if i % 10 == 0:
        print("Coding Dojo")
    print(i)

sum = 0
for i in range(1, 500000, 2):
    if i % 2 == 1:
        sum += i
print(sum)

for i in range(2018,1,-4):
    print(i)


for i in range(2, 11, 2):
    if i % 2==0:
        print(i)