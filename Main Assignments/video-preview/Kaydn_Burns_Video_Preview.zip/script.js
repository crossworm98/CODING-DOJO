console.log("page loaded...");
var x = document.getElementById("myvideo");
