function removed(element){
    element.remove();
}
function logout(element){
    element.innerText = "Log-out";
}
function notification(){
    alert("Ninja was liked")
}
