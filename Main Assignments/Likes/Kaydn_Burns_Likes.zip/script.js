
var neilcount= 9;

function likes(element){
    neilcount++;
    element.innerText = neilcount + " likes";
}

var niccount= 12;

function likes1(element){
    niccount++;
    element.innerText = niccount + " likes";
}

var jimcount= 9;

function likes2(element){
    jimcount++;
    element.innerText = jimcount + " likes";
}