package com.example.mvc.services;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.example.mvc.models.Ninja;
import com.example.mvc.repositories.NinjaRepository;


@Service
public class NinjaService {

	private final NinjaRepository ninjaRepository;
	
	
public NinjaService(NinjaRepository ninjaRepository) {
	this.ninjaRepository = ninjaRepository;
}


public List<Ninja> allNinjas() {
	return ninjaRepository.findAll();
}


public Ninja createNinja(Ninja x) {
	return ninjaRepository.save(x);
}

public Ninja findNinja(Long id) {
	Optional<Ninja> optionalNinja = ninjaRepository.findById(id);
	if(optionalNinja.isPresent()) {
		return optionalNinja.get();
	} else {
		return null;
	}
}

public void deleteNinja(Long id) {
	ninjaRepository.deleteById(id);
}
	
public Ninja updateNinja(Ninja ninja) {
	ninjaRepository.save(ninja);
	return null;
}

public Ninja updateNinja(Long id, String firstName, String lastName, Integer age) {
	Optional<Ninja> optionalNinja = ninjaRepository.findById(id);
	
	if(optionalNinja.isPresent()) {
		Ninja thisNinja = optionalNinja.get();
		thisNinja.setFirstName(firstName);
		thisNinja.setLastName(lastName);
		thisNinja.setAge(age);
		return thisNinja;
	} else {
		return null;
	}
}

}
