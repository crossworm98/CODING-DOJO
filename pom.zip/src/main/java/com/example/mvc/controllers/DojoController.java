package com.example.mvc.controllers;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.mvc.models.Dojo;
import com.example.mvc.services.DojoService;

@Controller
public class DojoController {

	@Autowired
	DojoService dojoService;
	
	@GetMapping("/dojos/new")
	public String index(Model model) {
		model.addAttribute("newDojo", new Dojo());
		return "index.jsp";
	}
	
	@PostMapping("/dojos/new/post")
	public String create(@Valid @ModelAttribute("newDojo") Dojo dojo, BindingResult result) {
		if(result.hasErrors()) {
			return "index.jsp";
		}
		dojoService.createDojo(dojo);
		return "redirect:/ninjas/new";
	}
}
