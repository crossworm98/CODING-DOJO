package com.example.mvc.controllers;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.mvc.models.Dojo;
import com.example.mvc.models.Ninja;
import com.example.mvc.services.DojoService;
import com.example.mvc.services.NinjaService;


@Controller
public class NinjaController {

	
	@Autowired
	NinjaService ninjaService;
	@Autowired
	DojoService dojoService;

	
	@GetMapping("/ninjas/new")
	public String index(Model model) {
		List<Dojo> alldojos = dojoService.allDojos();
		model.addAttribute("newNinja", new Ninja());
		model.addAttribute("alldojos", alldojos);
		return "/ninjas/new.jsp";
	}
	
	@PostMapping("/ninjas/new/post")
	public String create(@Valid @ModelAttribute("newNinja") Ninja ninja, BindingResult result) {
		if(result.hasErrors()) {
			return "/ninjas/new.jsp";
		}
		ninjaService.createNinja(ninja);
		return "redirect:/ninjasanddojos";
	}
	
	@GetMapping("/ninjasanddojos/{id}")
	public String pickme(Model model, @PathVariable("id") Long id) {
		 Dojo thisDojo = dojoService.findDojo(id);
		 model.addAttribute("dojo", thisDojo);
		 return "/ninjas/pickme.jsp";
		
	}
	
	
	
	
	
}
