//print Odds
for(var i = 0; i < 21; i++){
    if (i % 2 === 1)
    console.log(i)
}
// Decreasing multiples of 3
for(var i = 101; i > 0; i--){
    if (i % 3 === 0)
    console.log(i)
}
// Print the sequence
for(var i = -3.5; i < 5; i += 1.5){
    console.log(i)
}
//Sigma
var sum = 0
for(var i = 0; i < 101; i++){
    sum = sum + i;
}
console.log(sum)
//Factorial
var sum1 = 1
for(var i = 1; i < 13; i++){
    sum1 = sum1 * i
}
console.log(sum1)