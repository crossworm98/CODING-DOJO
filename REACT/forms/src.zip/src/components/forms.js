import React, { useState } from 'react';


const UserForm = (props) => {
    const [firstname, setFirstname] = useState("");
    const [lastname, setLastname] = useState("");
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [confirmpassword, setConfirmpassword] = useState("");
    


    const createUser = (e) => {
        e.preventDefault();
        const newUser = { firstname, lastname, email, password };
        console.log("Welcome", newUser);
    };
    

    return (
        <><form onSubmit={createUser}>
            <div>
                <label>First Name: </label>
                <input type="text" onChange={(e) => setFirstname(e.target.value)} />
                {firstname.length < 3 && firstname.length > 0 ? "Firstname must be at least 3 characters": "" }
            </div>
            <div>
                <label>Last Name: </label>
                <input type="text" onChange={(e) => setLastname(e.target.value)} />
                {lastname.length < 3 && lastname.length > 0 ? "Lastname must be at least 3 characters": "" }
            </div>
            <div>
                <label>Email Address: </label>
                <input type="text" onChange={(e) => setEmail(e.target.value)} />
                {email.length < 10 && email.length > 0 ? "Email must be at least 10 characters": "" }
            </div>
            <div>
                <label>Password: </label>
                <input type="text" onChange={(e) => setPassword(e.target.value)} />
                {password.length < 5 && password.length > 0 ? "Password must be at least 3 characters": "" }
            </div>
            <div>
                <label>Confirm Password: </label>
                <input type="text" onChange={(e) => setConfirmpassword(e.target.value)} />
                {password != confirmpassword ? "Passwords must match": "" }
            </div>
            <input type="submit" value="Create User" />
        </form>
        </>

    );
};

export default UserForm;
